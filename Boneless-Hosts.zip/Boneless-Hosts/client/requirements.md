## Packages
framer-motion | For smooth hover effects and page transitions

## Notes
Tailwind config should include 'Cairo' font for Arabic support.
Images: Hero background is external URL.
Data: Plans are fetched from /api/plans, Orders from /api/orders.
Language: Mixed English (Cards) and Arabic (Hero, Modal).
