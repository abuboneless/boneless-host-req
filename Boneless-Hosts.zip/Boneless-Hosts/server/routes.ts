import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

const plansData = {
  asia: [
    { name: "Starter", price: "$7.10", ram: "4GB", cpu: "250% CPU (2.5vCores)", storage: "16GB NVMe", slots: "12" },
    { name: "Basic", price: "$10", ram: "6GB", cpu: "325% CPU (3.25vCores)", storage: "24GB NVMe", slots: "20" },
    { name: "Master", price: "$13.63", ram: "8GB", cpu: "450% CPU (4.5vCores)", storage: "32GB NVMe", slots: "40" },
    { name: "Extreme", price: "$16.30", ram: "12GB", cpu: "550% CPU (5.5vCores)", storage: "48GB NVMe", slots: "70" },
    { name: "Boneless", price: "$23.25", ram: "16GB", cpu: "690% CPU (6.9vCores)", storage: "64GB NVMe", slots: "120" }
  ],
  eu: [
    { name: "X Starter", price: "$7.10", ram: "8GB", cpu: "Xeon E5-2680 v4 3.30 GHz", storage: "16GB NVMe", slots: "20" },
    { name: "X Basic", price: "$12.15", ram: "12GB", cpu: "Xeon E5-2680 v4 3.30 GHz", storage: "24GB NVMe", slots: "35" },
    { name: "X Master", price: "$14.20", ram: "16GB", cpu: "Xeon E5-2680 v4 3.30 GHz", storage: "32GB NVMe", slots: "50" },
    { name: "X Extreme", price: "$20.20", ram: "24GB", cpu: "Xeon E5-2680 v4 3.30 GHz", storage: "48GB NVMe", slots: "85" },
    { name: "X Boneless", price: "$25.20", ram: "32GB", cpu: "Xeon E5-2680 v4 3.30 GHz", storage: "56GB NVMe", slots: "150" },
    { name: "R Starter", price: "$7.10", ram: "4GB", cpu: "Ryzen 9 3900X 3.8GHz", storage: "16GB NVMe", slots: "15" },
    { name: "R Basic", price: "$10", ram: "6GB", cpu: "Ryzen 9 3900X 3.8GHz", storage: "24GB NVMe", slots: "25" },
    { name: "R Master", price: "$13.33", ram: "8GB", cpu: "Ryzen 9 3900X 3.8GHz", storage: "32GB NVMe", slots: "40" },
    { name: "R Extreme", price: "$20", ram: "12GB", cpu: "Ryzen 9 3900X 3.8GHz", storage: "48GB NVMe", slots: "70" },
    { name: "R Boneless", price: "$24.70", ram: "16GB", cpu: "Ryzen 9 3900X 3.8GHz", storage: "56GB NVMe", slots: "120" }
  ]
};

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  app.get(api.plans.list.path, (_req, res) => {
    res.json(plansData);
  });

  app.post(api.orders.create.path, async (req, res) => {
    try {
      const input = api.orders.create.input.parse(req.body);
      const order = await storage.createOrder(input);
      res.status(201).json(order);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  app.get(api.orders.list.path, async (_req, res) => {
    const orders = await storage.getOrders();
    res.json(orders);
  });

  return httpServer;
}
